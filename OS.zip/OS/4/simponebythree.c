#include <stdio.h>
#include <math.h>

// Define the function you want to integrate
#define f(x) 1/(1+pow(x,2))  // Example: f(x) = x^3

int main() {
    float lower, upper, h, result, x;
    int intervals;

    printf("\nEnter lower limit a: ");
    scanf("%f", &lower);

    printf("Enter upper limit b: ");
    scanf("%f", &upper);

    printf("Enter number of intervals (even number): ");
    scanf("%d", &intervals);

    // Check if number of intervals is even
    if (intervals % 2 != 0) {
        printf("\nError: Simpson's 1/3 rule requires an even number of intervals.\n");
        return 1;
    }

    h = (upper - lower) / intervals;
    result = f(lower) + f(upper);

    for (int i = 1; i < intervals; i++) {
        x = lower + i * h;
        if (i % 2 == 0)
            result += 2 * f(x);  // even index
        else
            result += 4 * f(x);  // odd index
    }

    result = (h / 3) * result;
    printf("\nRequired value of integration is: %.5f\n", result);

    return 0;
}
