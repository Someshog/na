#include <stdio.h>
#include <math.h>

// Define the function to integrate
#define f(x) 1/(1+pow(x,2))  // Example: f(x) = x^3

int main() {
    float lower, upper, h, x, result;
    int intervals;

    printf("\nEnter lower limit a: ");
    scanf("%f", &lower);

    printf("Enter upper limit b: ");
    scanf("%f", &upper);

    printf("Enter number of intervals (must be multiple of 3): ");
    scanf("%d", &intervals);

    // Check if intervals is a multiple of 3
    if (intervals % 3 != 0) {
        printf("\nError: Simpson's 3/8 rule requires number of intervals to be a multiple of 3.\n");
        return 1;
    }

    h = (upper - lower) / intervals;
    result = f(lower) + f(upper);

    for (int i = 1; i < intervals; i++) {
        x = lower + i * h;

        if (i % 3 == 0)
            result += 2 * f(x);  // Every third term
        else
            result += 3 * f(x);  // The rest
    }

    result *= (3 * h / 8);

    printf("\nRequired value of integration is: %.5f\n", result);

    return 0;
}
