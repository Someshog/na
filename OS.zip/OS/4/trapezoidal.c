#include <stdio.h>
#include <math.h>
#define f(x) 1 / (1 + x * x)

int main()
{
    float upper, lower, h, sum = 0, result = 0;
    int intervals;
    printf("\nLower Limit a - ");
    scanf("%f", &lower);
    printf("\nUpper Limit b - ");
    scanf("%f", &upper);
    printf("\nEnter no. of intervals - ");
    scanf("%d", &intervals);
    h = (upper - lower) / intervals;
    sum = f(lower) + f(upper);
    for (int i = 1; i < intervals; i++)
    {
        float x = lower + i * h; // Corrected the x-value
        sum += 2 * f(x);
    }
    result = h * sum / 2;
    printf("\nRequired value of integration is: %.4f", result);
}
