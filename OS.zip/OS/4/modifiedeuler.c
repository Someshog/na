#include <stdio.h>
#include <math.h>

#define F(x, y) ((x - y) / (x + y))  // Example function dy/dx = (x - y) / (x + y)

int main() {
    int i, n, itr;
    float x[100], y[100], yc, yp, h, p, xn;

    printf("\nEnter initial x, initial y, step size h, final x:\n");
    scanf("%f%f%f%f", &x[1], &y[1], &h, &xn);

    itr = (int)((xn - x[1]) / h);

    printf("\nX = %.4f\tY = %.6f\n", x[1], y[1]);

    for (i = 1; i <= itr; i++) {
        x[i + 1] = x[i] + h;
        yp = y[i] + h * F(x[i], y[i]);  // Predictor

        // Corrector iteration
        for (n = 1; n <= 50; n++) {
            yc = y[i] + (h / 2.0) * (F(x[i], y[i]) + F(x[i + 1], yp));
            p = fabs(yc - yp);
            printf("  Iter %d: yc = %.6f\n", n, yc);

            if (p < 0.0001) break;  // Convergence check
            yp = yc;
        }

        y[i + 1] = yc;

        printf("X = %.4f\tY = %.6f\n", x[i + 1], y[i + 1]);
    }

    return 0;
}
