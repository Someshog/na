#include <stdio.h>
#include <conio.h>
#include <math.h>

void main() {
    int n, i, j;
    float ax[10], ay[10], h, p, diff[20][20], x, y;
    float y1, y2, y3, y4;
    
    // Input Section
    printf("\nEnter the number of terms: ");
    scanf("%d", &n);
    
    printf("\nEnter the values for x:\n");
    for (i = 0; i < n; i++) {
        scanf("%f", &ax[i]);
    }
    
    printf("\nEnter the values for y:\n");
    for (i = 0; i < n; i++) {
        scanf("%f", &ay[i]);
    }
    
    printf("\nEnter the value of x for which you want y: ");
    scanf("%f", &x);
    
    // Compute finite differences
    h = ax[1] - ax[0];
    for (i = 0; i < n - 1; i++) {
        diff[i][1] = ay[i + 1] - ay[i];
    }
    for (j = 2; j <= 4; j++) {
        for (i = 0; i < n - j; i++) {
            diff[i][j] = diff[i + 1][j - 1] - diff[i][j - 1];
        }
    }
    
    // Finding the index where x fits in the table
    i = 0;
    while (ax[i] < x && i < n) {
        i++;
    }
    i--;
    
    // Bessel's Interpolation Calculation
    p = (x - ax[i]) / h;
    y1 = p * diff[i][1];
    y2 = (p * (p - 1) * diff[i][2] + diff[i - 1][2]) / 4;
    y3 = (p * (p - 1) * (p - 0.5) * diff[i - 1][3]) / 6;
    y4 = ((p + 1) * p * (p - 1) * (p - 2) * (diff[i - 2][4] + diff[i - 1][4])) / 48;
    
    
    y = ay[i] + y1 + y2 + y3 + y4;
    
    // Output the result
    printf("\nWhen x = %.2f, y = %.8f\n", x, y);
    
    printf("\nPress Enter to Exit\t");
    getch();
}
